# Deflection Calculator

A beam and plate deflection calculator for cabinet and woodworking design. Runs entirely in the browser — no server, no install, no account.

## Files in this bundle

- `index.html` — the calculator. This is the whole app.
- `sw.js` — service worker that caches everything for offline use after first load.
- `manifest.webmanifest` — tells iOS/Android this is an installable app.
- `icon-192.png`, `icon-512.png` — home-screen icons.
- `README.md` — this file.

You can use it three ways. Pick whichever fits your needs.

---

## Option A: Just open it locally (zero setup, ~30 seconds)

Double-click `index.html`. It opens in your browser and works immediately. No internet needed after first load (it caches the React/Tailwind libraries).

The downside: no home-screen icon on your phone, you have to find the file every time you want it.

## Option B: Email it to yourself for phone use (~2 minutes)

1. Email `index.html` to yourself as an attachment.
2. On your iPhone, tap the attachment, then tap **Save to Files** → **iCloud Drive** (or wherever).
3. Open the Files app, tap `index.html`, and it loads in Safari.
4. You can then tap **Share → Add to Home Screen** to put it on your home screen.

This works but is a little clunky because Safari treats local files differently than hosted ones. The full PWA experience needs Option C.

## Option C: GitHub Pages (~20 minutes, free, permanent)

This is the right answer. You get a real URL, the "Add to Home Screen" experience works fully (full-screen, offline, app-like), and you can share the URL with anyone.

### Step-by-step

**1. Create a GitHub account** at https://github.com if you don't have one. Free.

**2. Create a new repository.**
- Click the `+` in the top right → **New repository**.
- Repository name: `deflection-calc` (or whatever you like — this becomes part of your URL).
- Choose **Public** (required for free GitHub Pages, and lets you share the link).
- Check **Add a README file**.
- Click **Create repository**.

**3. Upload the files.**
- On the repo page, click **Add file** → **Upload files**.
- Drag all files from this bundle (`index.html`, `sw.js`, `manifest.webmanifest`, `icon-192.png`, `icon-512.png`) into the upload area.
- Scroll down, click **Commit changes**.

**4. Turn on GitHub Pages.**
- Click the **Settings** tab (top of the repo page).
- In the left sidebar, click **Pages**.
- Under "Build and deployment" → **Source**, choose **Deploy from a branch**.
- Under **Branch**, choose **main** and **/(root)**, then click **Save**.
- Wait 1–2 minutes. GitHub will show a green box with your URL: `https://<your-username>.github.io/deflection-calc/`

**5. Test it.** Open the URL in any browser. The calculator should load.

**6. Add to iPhone home screen.**
- Open the URL in **Safari** (this matters — Chrome on iOS doesn't support Add to Home Screen the same way).
- Tap the **Share** button (square with arrow up).
- Scroll down, tap **Add to Home Screen**.
- Tap **Add**. Now it's on your home screen with a proper icon, opens full-screen, and works offline once you've loaded it once.

**7. Share with others.** Just send them the URL. They can use it in any browser, or also Add to Home Screen on their own phones.

### Updating the calculator later

If we make improvements, you can update by:
1. Going to your repo on GitHub.
2. Clicking on `index.html`.
3. Clicking the pencil icon to edit.
4. Pasting in the new content, scrolling down, clicking **Commit changes**.

GitHub Pages re-deploys automatically within a minute or two. Your phone will pick up the new version next time you open the app while online.

---

## Privacy / data

The calculator runs entirely in your browser. Nothing leaves your device — there's no server logging, no analytics, nothing tracked. The only network calls happen on first load to fetch React/Tailwind from CDNs (cached forever after).

## License

Use it however you want. This is a personal tool, not a product.
